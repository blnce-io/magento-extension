var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Balancepay_Balancepay/js/admin-config/validator-rules-mixin': true
            }
        }
    }
};
